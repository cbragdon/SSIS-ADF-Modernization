#Requires -Version 5.1
<#
.SYNOPSIS
    Regression test for 01_Invoke-SsisModernizationAssessment.ps1: runs the assessment against known
    test packages and compares every package's route to the expected route.

.DESCRIPTION
    TWO MODES
    ---------
    Fixtures (default, offline)
        Runs the assessment against tests\fixtures (hand-written XML covering cases that cannot be built
        on a modern SSIS install: encrypted and SSIS 2008 packages, Attunity CDC, third-party tasks,
        percent-encoded .ispac part names). Needs no SQL Server - suitable for a CI job on every commit.
        Each distinct TargetSsisVersion in the expected file is run separately.

    Server
        Runs the assessment against the AssessmentTests project deployed by 02_Deploy-SsisTestProject.ps1
        and compares it with tests\expected\AssessmentTests_expected_routes.csv. Packages that the builder
        skipped (component not installed; see build\build_manifest_<ProjectName>.csv) are reported SKIP, not FAIL.

    CHECKS
    ------
    * PackageRoute and EffectiveRoute equal the expected values.
    * Every token in the optional ExpectedReasons column ('|'-separated) appears in RouteReasons, so a
      case is proven to route for the right reason, not just to the right route. A token that starts
      with '!' must be absent (for example a commented-out dependency that must not be reported).
    * Every expected package was found (missing = FAIL unless the build manifest says it was skipped).
    * No secret test value appears in any assessment output file (password masking).
    * The assessment reported zero errors (errors.csv empty).
    * Sprint backlog: sprint_backlog.csv has one row per assessed package, every expected package lands on
      the platform its expected EffectiveRoute maps to, every parent's BuildOrder is higher than each
      child's, and each source server gets one readable <ServerName>_SSIS_Migration_Assessment_<yyyyMMdd_HHmmss>.xlsx
      in a -WorkbookFolder the run had to create (and log); together their Backlog sheets hold every CSV row.
      transcript.log announces each source's start and completion time.
      The secret scan reads the XML inside the workbook too. Every DecisionDrivers entry is a full sentence
      that explains the finding, never a bare component name, and no rule is missing its plain-language text
      (the assessment's RULE-EXPLANATION-MISSING warning in transcript.log).

    Exit code 0 when everything passes, 1 otherwise, so the script can gate a pull request.

.PARAMETER Mode
    Fixtures | Server.

.PARAMETER ServerInstance
    Server mode: the Dev server where the test project is deployed.

.PARAMETER FolderName / ProjectName
    Server mode: SSISDB location of the test project. Defaults ZZ_AssessmentTests / AssessmentTests.

.PARAMETER OutputRoot
    Where assessment output and the test report are written. Default C:\Temp\SSIS_AssessmentTests
    (a scratch folder under the system temp path on non-Windows CI runners).

.EXAMPLE
    .\03_Test-AssessmentRouting.ps1                      # offline fixtures
.EXAMPLE
    .\03_Test-AssessmentRouting.ps1 -Mode Server -ServerInstance <DevSqlServer> -TrustServerCertificate

.NOTES
    Version : 1.5.0
    Compat  : Windows PowerShell 5.1 and PowerShell 7.x.
#>
[CmdletBinding()]
param(
    [ValidateSet('Fixtures', 'Server')][string]$Mode = 'Fixtures',
    [string]$ServerInstance,
    [string]$FolderName = 'ZZ_AssessmentTests',
    [string]$ProjectName = 'AssessmentTests',
    [string]$OutputRoot,
    [switch]$TrustServerCertificate,
    [System.Management.Automation.PSCredential]$SqlCredential
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$RepoRoot   = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$Assessment = Join-Path $RepoRoot 'scripts\assessment\01_Invoke-SsisModernizationAssessment.ps1'
if (-not $OutputRoot) {
    $OutputRoot = if ($env:OS -eq 'Windows_NT') { 'C:\Temp\SSIS_AssessmentTests' } else { Join-Path ([IO.Path]::GetTempPath()) 'SSIS_AssessmentTests' }
}
New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null

# Secret values planted in fixtures/test packages. None may appear in assessment output.
$PlantedSecrets = @('Secret123', 'hunter2')

# Platform each route must land on in sprint_backlog.csv. Kept independent of the assessment's own table on purpose.
$ExpectedPlatform = @{
    'AdfNative-Low' = 'ADF'; 'AdfNative-Medium' = 'ADF'; 'KeepOnSsisVm' = 'SSIS VM'
    'Remediate2025' = 'SSIS VM after remediation'; 'ReviewRequired' = 'Undetermined'
}
Add-Type -AssemblyName System.IO.Compression

function Read-XlsxParts {
    <# Returns @{ partName = text } for every part of an .xlsx (a zip of XML). #>
    param([string]$Path)
    $out = @{}
    $fs = [IO.File]::OpenRead($Path)
    try {
        $zip = New-Object System.IO.Compression.ZipArchive($fs, [IO.Compression.ZipArchiveMode]::Read)
        try {
            foreach ($en in $zip.Entries) {
                $r = New-Object System.IO.StreamReader($en.Open())
                try { $out[$en.FullName] = $r.ReadToEnd() } finally { $r.Dispose() }
            }
        }
        finally { $zip.Dispose() }
    }
    finally { $fs.Dispose() }
    $out
}

function Write-Result { param([string]$Status, [string]$Text)
    $c = @{ PASS = 'Green'; FAIL = 'Red'; SKIP = 'Yellow'; INFO = 'Gray' }[$Status]
    Write-Host ('[{0}] {1}' -f $Status, $Text) -ForegroundColor $c
}

function Invoke-AssessmentRun {
    <# Runs the assessment in a child scope and returns the run folder it created. #>
    param([hashtable]$Arguments)
    $before = @(Get-ChildItem -LiteralPath $OutputRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object FullName)
    # 6>$null hides the child run's Write-Host console output; errors still surface.
    & $Assessment @Arguments -OutputRoot $OutputRoot 6>$null | Out-Null
    $after = @(Get-ChildItem -LiteralPath $OutputRoot -Directory -Filter 'SSISASSESS_*' | Where-Object { $before -notcontains $_.FullName } | Sort-Object LastWriteTime)
    if ($after.Count -eq 0) { throw 'Assessment did not create a run folder.' }
    return $after[-1].FullName
}

$results = New-Object System.Collections.Generic.List[object]
# Each run writes its workbooks to a folder that does not exist yet, so the test also proves the assessment
# creates -WorkbookFolder and logs the creation.
$wbFolders = @{}
function New-WorkbookFolderPath { param([string]$Ver) Join-Path (Join-Path $OutputRoot 'workbooks') ('{0}_{1}_{2}' -f $Mode, $Ver, (Get-Date -Format 'yyyyMMdd_HHmmss')) }

if ($Mode -eq 'Fixtures') {
    $expected = @(Import-Csv (Join-Path $RepoRoot 'tests\expected\fixtures_expected_routes.csv'))
    $fixtures = Join-Path $RepoRoot 'tests\fixtures'
    $runs = @{}
    foreach ($ver in ($expected | Select-Object -ExpandProperty TargetSsisVersion -Unique)) {
        Write-Result INFO "Running assessment on fixtures, target SQL Server $ver"
        # Run ids are per second; pause so consecutive runs never share a folder name.
        Start-Sleep -Seconds 1
        $wbFolders[$ver] = New-WorkbookFolderPath $ver
        $runs[$ver] = Invoke-AssessmentRun @{ PackageFolder = $fixtures; TargetSsisVersion = $ver; Environment = 'Fixtures'; WorkbookFolder = $wbFolders[$ver] }
    }
    $manifest = @()
}
else {
    if (-not $ServerInstance) { throw '-ServerInstance is required in Server mode.' }
    $expected = @(Import-Csv (Join-Path $RepoRoot 'tests\expected\AssessmentTests_expected_routes.csv'))
    $runs = @{}
    foreach ($ver in ($expected | Select-Object -ExpandProperty TargetSsisVersion -Unique)) {
        $wbFolders[$ver] = New-WorkbookFolderPath $ver
        $a = @{ ServerInstance = $ServerInstance; TargetSsisVersion = $ver; Environment = 'Development'; WorkbookFolder = $wbFolders[$ver] }
        if ($TrustServerCertificate) { $a.TrustServerCertificate = $true }
        if ($SqlCredential) { $a.SqlCredential = $SqlCredential }
        Start-Sleep -Seconds 1
        $runs[$ver] = Invoke-AssessmentRun $a
    }
    # Per-project manifest (builder 1.2.1+). The shared build_manifest.csv of older builds is read only for its
    # rows of this project: it holds whichever suite was built last.
    $manifest = @()
    foreach ($name in @(('build_manifest_{0}.csv' -f $ProjectName), 'build_manifest.csv')) {
        $mPath = Join-Path $RepoRoot ('build\' + $name)
        if (Test-Path -LiteralPath $mPath) {
            $manifest = @(Import-Csv $mPath | Where-Object { -not $_.PSObject.Properties['ProjectName'] -or $_.ProjectName -eq $ProjectName })
            if ($manifest.Count -gt 0) { Write-Result INFO "Build manifest: $mPath"; break }
        }
    }
    if ($manifest.Count -eq 0) { Write-Result INFO "No build manifest for $ProjectName under build\: packages the builder skipped will report FAIL, not SKIP. Rebuild with 01_New-SsisTestProject.ps1 to restore it." }
}

foreach ($ver in $runs.Keys) {
    $run = $runs[$ver]
    $allActual = @(Import-Csv (Join-Path $run 'package_assessment.csv'))
    $actual = $allActual
    if ($Mode -eq 'Server') { $actual = @($actual | Where-Object { $_.Folder -eq $FolderName -and $_.Project -eq $ProjectName }) }

    # Assessment errors
    $errs = @(Import-Csv (Join-Path $run 'errors.csv'))
    $results.Add([PSCustomObject]@{ Target = $ver; Check = 'Assessment errors'; Package = '-'; Expected = '0'; Actual = "$($errs.Count)"; Status = $(if ($errs.Count -eq 0) { 'PASS' } else { 'FAIL' }) })

    # Versioned JSON contract: downstream automation must not have to parse workbooks or console output.
    $manifestPath = Join-Path $run 'assessment_manifest.json'
    $packagesJsonPath = Join-Path $run 'package_assessment.json'
    $summaryJsonPath = Join-Path $run 'route_summary.json'
    $jsonReady = (Test-Path -LiteralPath $manifestPath) -and (Test-Path -LiteralPath $packagesJsonPath) -and (Test-Path -LiteralPath $summaryJsonPath)
    $results.Add([PSCustomObject]@{ Target = $ver; Check = 'JSON artifacts'; Package = '-'; Expected = 'manifest, packages, summary'; Actual = $(if ($jsonReady) { 'present' } else { 'missing' }); Status = $(if ($jsonReady) { 'PASS' } else { 'FAIL' }) })
    $manifest = $null; $packageJson = @(); $summaryJson = @()
    if ($jsonReady) {
        try {
            $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
            $packageJson = Get-Content -LiteralPath $packagesJsonPath -Raw | ConvertFrom-Json
            $summaryJson = Get-Content -LiteralPath $summaryJsonPath -Raw | ConvertFrom-Json
        }
        catch {
            $jsonReady = $false
        }
    }
    $manifestOk = $jsonReady -and $manifest.SchemaVersion -eq '1.0' -and $manifest.RunId -and
                  [int]$manifest.Counts.Packages -eq $allActual.Count
    $results.Add([PSCustomObject]@{ Target = $ver; Check = 'JSON manifest'; Package = '-'; Expected = 'schema 1.0 and package count'; Actual = $(if ($manifestOk) { 'valid' } else { 'invalid' }); Status = $(if ($manifestOk) { 'PASS' } else { 'FAIL' }) })
    $packageJsonOk = $jsonReady -and $packageJson.Count -eq $allActual.Count -and
                     @($packageJson | Select-Object -ExpandProperty PackageKey -Unique).Count -eq $packageJson.Count
    $results.Add([PSCustomObject]@{ Target = $ver; Check = 'JSON packages'; Package = '-'; Expected = "$($allActual.Count) unique package keys"; Actual = $(if ($jsonReady) { "$($packageJson.Count) package records, $(@($packageJson | Select-Object -ExpandProperty PackageKey -Unique).Count) unique keys" } else { 'unavailable' }); Status = $(if ($packageJsonOk) { 'PASS' } else { 'FAIL' }) })
    $summaryCsv = @(Import-Csv (Join-Path $run 'route_summary.csv'))
    $summaryCsvKeys = @($summaryCsv | ForEach-Object { '{0}|{1}|{2}' -f $_.Environment, $_.EffectiveRoute, $_.Packages } | Sort-Object)
    $summaryJsonKeys = @($summaryJson | ForEach-Object { '{0}|{1}|{2}' -f $_.Environment, $_.EffectiveRoute, $_.Packages } | Sort-Object)
    $summaryJsonOk = $jsonReady -and (($summaryCsvKeys -join "`n") -eq ($summaryJsonKeys -join "`n"))
    $results.Add([PSCustomObject]@{ Target = $ver; Check = 'JSON route summary'; Package = '-'; Expected = 'matches route_summary.csv'; Actual = $(if ($summaryJsonOk) { 'matches' } else { 'does not match' }); Status = $(if ($summaryJsonOk) { 'PASS' } else { 'FAIL' }) })

    # Secret masking: scan every output file, workbooks included
    foreach ($f in @(Get-ChildItem -LiteralPath $run -File) + @(Get-ChildItem -LiteralPath $wbFolders[$ver] -File -ErrorAction SilentlyContinue)) {
        # .xlsx is compressed: scan the XML parts, not the zip bytes.
        $text = if ($f.Extension -eq '.xlsx') { (Read-XlsxParts -Path $f.FullName).Values -join "`n" } else { Get-Content -LiteralPath $f.FullName -Raw }
        foreach ($s in $PlantedSecrets) {
            if ($text -and $text.Contains($s)) {
                $results.Add([PSCustomObject]@{ Target = $ver; Check = 'Secret masking'; Package = $f.Name; Expected = 'absent'; Actual = "found '$s'"; Status = 'FAIL' })
            }
        }
    }

    # Sprint backlog: one row per package, workbook readable and in step with the CSV.
    $backlogPath = Join-Path $run 'sprint_backlog.csv'
    $backlog = if (Test-Path -LiteralPath $backlogPath) { @(Import-Csv $backlogPath) } else { @() }
    $allCount = $backlog.Count
    if ($Mode -eq 'Server') { $backlog = @($backlog | Where-Object { $_.Folder -eq $FolderName -and $_.Project -eq $ProjectName }) }
    $results.Add([PSCustomObject]@{ Target = $ver; Check = 'Backlog rows'; Package = '-'; Expected = "$($actual.Count)"; Actual = "$($backlog.Count)"
        Status = $(if ((Test-Path -LiteralPath $backlogPath) -and $backlog.Count -eq $actual.Count) { 'PASS' } else { 'FAIL' }) })
    # Workbooks: one per source server in -WorkbookFolder, named <ServerName>_SSIS_Migration_Assessment_<yyyyMMdd_HHmmss>.xlsx.
    # The folder did not exist before the run, so the transcript must record its creation.
    $wbDir = $wbFolders[$ver]
    $transcriptText = Get-Content -LiteralPath (Join-Path $run 'transcript.log') -Raw
    $logged = $transcriptText.Contains("Created folder (did not exist): $wbDir")
    $results.Add([PSCustomObject]@{ Target = $ver; Check = 'Workbook folder created'; Package = '-'; Expected = 'created and logged'
        Actual = $(if (-not (Test-Path -LiteralPath $wbDir)) { 'missing' } elseif (-not $logged) { 'created, not logged' } else { 'created and logged' })
        Status = $(if ((Test-Path -LiteralPath $wbDir) -and $logged) { 'PASS' } else { 'FAIL' }) })
    $workbooks = @(Get-ChildItem -LiteralPath $wbDir -File -Filter '*.xlsx' -ErrorAction SilentlyContinue)
    $wantNames = if ($Mode -eq 'Server') { @(Import-Csv $backlogPath | ForEach-Object { $_.SourceServerName -replace '[\\/:*?"<>|]', '_' } | Sort-Object -Unique) } else { @('FileSystem') }
    $gotNames = @($workbooks | ForEach-Object { if ($_.Name -match '^(.+)_SSIS_Migration_Assessment_\d{8}_\d{6}\.xlsx$') { $Matches[1] } else { "(bad name: $($_.Name))" } } | Sort-Object)
    $results.Add([PSCustomObject]@{ Target = $ver; Check = 'Workbook per server'; Package = '-'
        Expected = (@($wantNames | ForEach-Object { "${_}_SSIS_Migration_Assessment_<yyyyMMdd_HHmmss>.xlsx" }) -join '; ')
        Actual = $(if ($workbooks.Count) { ($workbooks.Name -join '; ') } else { 'none' })
        Status = $(if (($gotNames -join '|') -eq (($wantNames | Sort-Object) -join '|')) { 'PASS' } else { 'FAIL' }) })
    $xlsxRows = 0
    $sheetHeaders = @{}
    foreach ($wb in $workbooks) {
        try {
            $xl = Read-XlsxParts -Path $wb.FullName
            [xml]$wbXml = $xl['xl/workbook.xml']
            $sheetNames = @($wbXml.workbook.sheets.sheet | ForEach-Object { $_.name })
            $idx = [array]::IndexOf($sheetNames, 'Backlog')
            if ($idx -ge 0) { [xml]$sheetXml = $xl["xl/worksheets/sheet$($idx + 1).xml"]; $xlsxRows += @($sheetXml.worksheet.sheetData.row).Count - 1 }
            for ($i = 0; $i -lt $sheetNames.Count; $i++) {
                [xml]$sx = $xl["xl/worksheets/sheet$($i + 1).xml"]
                $sheetHeaders[$sheetNames[$i]] = @(@($sx.worksheet.sheetData.row)[0].c | ForEach-Object { $_.InnerText })
            }
        }
        catch { $xlsxRows = -1; break }
    }
    $results.Add([PSCustomObject]@{ Target = $ver; Check = 'Backlog workbook'; Package = '-'; Expected = "$allCount rows"; Actual = "$xlsxRows rows"
        Status = $(if ($workbooks.Count -gt 0 -and $xlsxRows -eq $allCount) { 'PASS' } else { 'FAIL' }) })
    # Each source is announced with its start and completion time.
    $progressOk = $transcriptText -match '\] (Server|Folder) .+: started \d{4}-\d{2}-\d{2} ' -and $transcriptText -match '\] (Server|Folder) .+: completed \d{4}-\d{2}-\d{2} .*elapsed' -and $transcriptText.Contains('Assessment completed ')
    $results.Add([PSCustomObject]@{ Target = $ver; Check = 'Progress log'; Package = '-'; Expected = 'start and completion per source'
        Actual = $(if ($progressOk) { 'start and completion per source' } else { 'missing in transcript.log' }); Status = $(if ($progressOk) { 'PASS' } else { 'FAIL' }) })
    # PackageLocation then isMigrating sit immediately right of Package, in the CSV and on every package sheet,
    # and ServerInstance is not a column (SourceServerName identifies the server).
    $wantCols = 'Package,PackageLocation,isMigrating'
    $placement = @{ 'CSV' = @(if (Test-Path -LiteralPath $backlogPath) { (Get-Content -LiteralPath $backlogPath -TotalCount 1) -split ',' | ForEach-Object { $_.Trim('"') } }) }
    foreach ($sn in @($sheetHeaders.Keys | Where-Object { $_ -notin @('Summary', 'Legend') })) { $placement[$sn] = $sheetHeaders[$sn] }
    $badPlacement = @(foreach ($k in @($placement.Keys | Sort-Object)) {
        $h = @($placement[$k]); $i = [array]::IndexOf($h, 'Package')
        if ($i -lt 0 -or $i + 2 -ge $h.Count -or (($h[$i..($i + 2)]) -join ',') -ne $wantCols -or $h -contains 'ServerInstance') { $k }
    })
    $results.Add([PSCustomObject]@{ Target = $ver; Check = 'Backlog columns'; Package = '-'; Expected = "$wantCols on CSV, Backlog and platform sheets; no ServerInstance"
        Actual = $(if ($badPlacement.Count -eq 0 -and $placement.Count -ge 3) { "ok on $(@($placement.Keys | Sort-Object) -join ', ')" } else { "wrong on $($badPlacement -join ', ') (checked $($placement.Count))" })
        Status = $(if ($badPlacement.Count -eq 0 -and $placement.Count -ge 3) { 'PASS' } else { 'FAIL' }) })
    # Fixtures are loose .dtsx files plus one .ispac.
    $expectedLocation = if ($Mode -eq 'Server') { @('SSISDB') } else { @('File system', 'File system (.ispac)') }
    foreach ($b in $backlog) {
        $okLoc = $b.PackageLocation -in $expectedLocation
        $okMig = $b.isMigrating -in @('Yes', 'Review')
        $results.Add([PSCustomObject]@{ Target = $ver; Check = 'PackageLocation/isMigrating'; Package = $b.Package
            Expected = "$($expectedLocation -join ' or ') / Yes or Review"; Actual = "$($b.PackageLocation) / $($b.isMigrating)"
            Status = $(if ($okLoc -and $okMig) { 'PASS' } else { 'FAIL' }) })
    }
    # Every rule needs plain-language text. The assessment logs RULE-EXPLANATION-MISSING (and keeps running)
    # when one is missing; here that fails the build, so the gap never reaches a business reader.
    $transcript = Join-Path $run 'transcript.log'
    $missingText = @(if (Test-Path -LiteralPath $transcript) { Select-String -LiteralPath $transcript -Pattern 'RULE-EXPLANATION-MISSING: no plain-language text for (.*?)\. The backlog' | ForEach-Object { $_.Matches[0].Groups[1].Value } | Select-Object -First 1 })
    $results.Add([PSCustomObject]@{ Target = $ver; Check = 'RuleExplanations'; Package = '-'; Expected = 'all rules'
        Actual = $(if ($missingText.Count -eq 0) { 'all rules' } else { "missing $($missingText[0])" }); Status = $(if ($missingText.Count -eq 0) { 'PASS' } else { 'FAIL' }) })
    # Decision drivers must explain, not just name: every ' | '-separated driver is a full sentence (at least
    # 60 characters, ending in a full stop). A bare label such as 'Excel Destination' fails.
    foreach ($b in $backlog) {
        $bare = @($b.DecisionDrivers -split ' \| ' | Where-Object { $_.Length -lt 60 -or -not $_.TrimEnd().EndsWith('.') })
        $ok = ($b.DecisionDrivers -and $bare.Count -eq 0)
        $results.Add([PSCustomObject]@{ Target = $ver; Check = 'DriverExplained'; Package = "$($b.Project)\$($b.Package)"
            Expected = 'sentences'; Actual = $(if ($ok) { 'sentences' } else { "bare: $($bare -join ' / ')" }); Status = $(if ($ok) { 'PASS' } else { 'FAIL' }) })
    }
    # Build order: within a project, every parent comes after each child it executes.
    foreach ($grp in ($backlog | Group-Object SourceServerName, Folder, Project)) {
        $order = @{}; foreach ($b in $grp.Group) { $order[$b.Package] = [int]$b.BuildOrder }
        foreach ($b in $grp.Group) {
            foreach ($c in @($b.DependsOn -split '; ' | Where-Object { $_ -and $order.ContainsKey($_) })) {
                $ok = [int]$b.BuildOrder -gt $order[$c]
                $results.Add([PSCustomObject]@{ Target = $ver; Check = 'BuildOrder'; Package = "$($b.Project)\$($b.Package)"
                    Expected = "> $c ($($order[$c]))"; Actual = $b.BuildOrder; Status = $(if ($ok) { 'PASS' } else { 'FAIL' }) })
            }
        }
    }

    foreach ($e in ($expected | Where-Object TargetSsisVersion -eq $ver)) {
        $match = @($actual | Where-Object {
            $_.Package -eq $e.Package -and $_.Project -eq $e.Project -and $_.SourceType -eq $e.Source
        })
        if ($match.Count -eq 0) {
            $m = @($manifest | Where-Object Package -eq $e.Package)
            $status = if ($m.Count -gt 0 -and $m[0].Built -eq 'False') { 'SKIP' } else { 'FAIL' }
            $results.Add([PSCustomObject]@{ Target = $ver; Check = 'Package found'; Package = "$($e.Project)\$($e.Package)"; Expected = 'present'; Actual = 'missing'; Status = $status })
            continue
        }
        $a = $match[0]
        foreach ($pair in @(@('PackageRoute', $e.ExpectedRoute), @('EffectiveRoute', $e.ExpectedEffectiveRoute))) {
            $ok = ($a.($pair[0]) -eq $pair[1])
            $results.Add([PSCustomObject]@{
                Target = $ver; Check = $pair[0]; Package = "$($e.Project)\$($e.Package)"
                Expected = $pair[1]; Actual = $a.($pair[0]); Status = $(if ($ok) { 'PASS' } else { 'FAIL' })
            })
        }
        $bl = @($backlog | Where-Object { $_.Package -eq $a.Package -and $_.Project -eq $a.Project -and $_.Folder -eq $a.Folder })
        $platform = if ($bl.Count -gt 0) { $bl[0].TargetPlatform } else { 'missing' }
        $results.Add([PSCustomObject]@{
            Target = $ver; Check = 'TargetPlatform'; Package = "$($e.Project)\$($e.Package)"
            Expected = $ExpectedPlatform[$e.ExpectedEffectiveRoute]; Actual = $platform
            Status = $(if ($platform -eq $ExpectedPlatform[$e.ExpectedEffectiveRoute]) { 'PASS' } else { 'FAIL' })
        })
        # Optional reason checks: each token must appear in the package's RouteReasons (case-insensitive), or be absent when negated.
        if ($e.PSObject.Properties['ExpectedReasons'] -and $e.ExpectedReasons) {
            foreach ($token in ($e.ExpectedReasons -split '\|' | ForEach-Object { $_.Trim() } | Where-Object { $_ })) {
                # A leading '!' means the token must NOT appear (proves a false positive is suppressed).
                $negate = $token.StartsWith('!')
                $text   = $token.TrimStart('!').Trim()
                $found  = ([string]$a.RouteReasons).IndexOf($text, [StringComparison]::OrdinalIgnoreCase) -ge 0
                $ok     = $found -ne $negate
                $results.Add([PSCustomObject]@{
                    Target = $ver; Check = 'RouteReason'; Package = "$($e.Project)\$($e.Package)"
                    Expected = $token; Actual = $(if ($found) { 'present' } else { 'missing' }); Status = $(if ($ok) { 'PASS' } else { 'FAIL' })
                })
            }
        }
    }
}

foreach ($r in $results) { Write-Result $r.Status ('{0} | {1,-15} | {2,-45} expected {3,-16} actual {4}' -f $r.Target, $r.Check, $r.Package, $r.Expected, $r.Actual) }
$reportPath = Join-Path $OutputRoot ('routing_test_{0}_{1}.csv' -f $Mode, (Get-Date -Format 'yyyyMMdd_HHmmss'))
$results | Export-Csv -Path $reportPath -NoTypeInformation -Encoding UTF8

$fail = @($results | Where-Object Status -eq 'FAIL').Count
$pass = @($results | Where-Object Status -eq 'PASS').Count
$skip = @($results | Where-Object Status -eq 'SKIP').Count
Write-Host ''
Write-Result $(if ($fail) { 'FAIL' } else { 'PASS' }) ("{0} passed, {1} failed, {2} skipped. Report: {3}" -f $pass, $fail, $skip, $reportPath)
if ($fail) { exit 1 } else { exit 0 }
